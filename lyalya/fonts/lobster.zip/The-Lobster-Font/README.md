The Lobster Font
======================

The latest version (currently v1.7) of The Lobster Font.

## License

- The Lobster Font is licensed under the SIL Open Font License v1.1 (<http://scripts.sil.org/OFL>)
- To view the copyright and specific terms and conditions please refer to [OFL.txt](https://github.com/impallari/The-Lobster-Font/blob/master/OFL.txt)

## Authors

[Pablo Impallari](http://www.impallari.com). Cyrillic by [Alexei Vanyashin](http://www.cyreal.org/)
